'''
本文件用于定义多目标需要的各个类或者相关的工具函数
'''
from typing import Dict, List
from OptimAlgorithm.Algorithm.codebase.utils.constraintHelper import min_float, CompareOpNode, VariableNode, NumberNode, BinaryOpNode, Parser, Lexer


class ScalarComputeConst:
    # 标量计算类型常量
    MINIMUM = "00"  # 曲线最小值
    MAXIMUM = "01"  # 曲线最大值
    AVERAGE = "02"  # 曲线平均值
    VALLEY_BANDWIDTH = "03"    # 曲线带宽（负方向，谷值定义的）
    PEAK_BANDWIDTH = "04"   # 曲线带宽（正方向，峰值定义的）
    NUM_VALLEY = "05"       # 曲线谐振点数量（波谷的数量）
    NUM_PEAK = "06"  # 曲线谐振点数量（波峰数量）
    ADD = "10"
    SUB = "11"
    MUL = "12"
    DIV = "13"
    All_Values = "14"

class TargetComputeConst:
    # 目标优化方向常量
    MINIMIZE = 1
    MAXIMIZE = 2


class DataSourceInfo:
    """
        存储数据源信息
    """

    def __init__(self, datasource_info: Dict):
        # 数据源id
        self.id = datasource_info['id']
        # 数据源名称
        self.name = datasource_info['name']


class CurveDataSourceInfo(DataSourceInfo):
    """
        存储曲线数据源信息
    """

    def __init__(self, curve_datasource_info: Dict):
        super(CurveDataSourceInfo, self).__init__(curve_datasource_info)
        # 数据源曲线表征维度
        self.data_dim = curve_datasource_info['data_dimension']
        # 数据源曲线在总曲线中的起始index
        self.start_point = curve_datasource_info['start_point']
        # 数据源曲线在总曲线中的终止index
        self.end_point = curve_datasource_info['end_point']

    def __str__(self):
        return f"{self.name:^50}{self.data_dim:^10}{self.start_point:^10}{self.end_point:^10}"


# def fun(curve_datasource_info_list: List[CurveDataSourceInfo]):
#     start_point = 0
#     end_point = 0
#     new_curve_datasource_info_list = []
#     for curve_datasource_info in curve_datasource_info_list:
#         end_point = start_point + curve_datasource_info.data_dim
#         curve_datasource_info.start_point = start_point
#         curve_datasource_info.end_point = end_point
#         start_point = end_point
#         new_curve_datasource_info_list.append(curve_datasource_info)
#
#     return new_curve_datasource_info_list


class DataSourceInfoFactory:
    def __init__(self):
        pass

    @staticmethod
    def create_data_source_info(datasource_info: Dict) -> DataSourceInfo:
        type = datasource_info["data_source_type"]
        if type == "curve":
            return CurveDataSourceInfo(datasource_info)
        else:
            raise NotImplementedError()


class ScalarInfo:
    """
        存储标量计算的操作信息
    """

    def __init__(self, scalar_info: Dict, **kargs):
        # 标量id
        self.id = str(scalar_info['scalar_id'])
        # 标量名称
        self.name = scalar_info['name']


class ScalarFromCurveInfo(ScalarInfo):
    """
        存储数据源为曲线的标量计算操作信息
    """

    def __init__(self, scalar_info: Dict, **kargs):
        super(ScalarFromCurveInfo, self).__init__(scalar_info)
        datasource_info = scalar_info['source_info']
        self.datasource_info: CurveDataSourceInfo = CurveDataSourceInfo(datasource_info)
        self.freq = scalar_info["frequency_range"]
        operator = scalar_info["operator"]
        self.operate_str = operator
        if operator == "Min":
            self.operate = ScalarComputeConst.MINIMUM
        elif operator == "Max":
            self.operate = ScalarComputeConst.MAXIMUM
        elif operator == "Avg":
            self.operate = ScalarComputeConst.AVERAGE
        elif operator == "Valley Bandwidth":
            self.operate = ScalarComputeConst.VALLEY_BANDWIDTH
        elif operator == "Peak Bandwidth":
            self.operate = ScalarComputeConst.PEAK_BANDWIDTH
        elif operator == "Number of Valley":
            self.operate = ScalarComputeConst.NUM_VALLEY
        elif operator == "Number of Peak":
            self.operate = ScalarComputeConst.NUM_PEAK
        elif operator == "All Values":
            self.operate = ScalarComputeConst.All_Values
        else:
            self.operate = None
            raise NotImplementedError()
        self.bw_base = scalar_info.get("bw_base", None)

    def __str__(self):
        return f"{self.name:^10}{self.datasource_info.name:^50}{self.operate_str:^10}{self.bw_base if self.bw_base is not None else '/':^10}"


class ScalarFromScalarInfo(ScalarInfo):

    def __init__(self, scalar_info: Dict, global_scalar_info_dict: Dict, **kargs):
        super(ScalarFromScalarInfo, self).__init__(scalar_info)
        self.expression = scalar_info["expression"]
        self.parser = Parser(Lexer(self.expression).tokens)
        self.datasource_info_dict = {}
        # 遍历 token 列表，但使用索引以便“向后看”
        tokens = self.parser.tokens
        for i in range(len(tokens)):
            token_type, token_name = tokens[i]

            if token_type == "VARIABLE":
                is_function = False
                # 检查是否还有下一个 token，并且下一个 token 是 '('
                if i + 1 < len(tokens) and tokens[i + 1][0] == 'LPAREN':
                    is_function = True

                # 只有当它不是函数名时，才将其视为变量
                if not is_function:
                    if self.datasource_info_dict.get(token_name, None) is None:
                        # 这一行现在是安全的，token_name 不会是 'abs'
                        datasource_info_dict_i = global_scalar_info_dict[token_name]
                        self.datasource_info_dict[token_name] = ScalarInfoFactory.create_scalar_info(datasource_info_dict_i)

    def __str__(self):
        return f"{self.name:^10}{self.expression:^15}"


class ScalarInfoFactory:
    global_scalar_info_dict = {}

    @staticmethod
    def update_global_scalar_info_dict(global_scalar_info_dict_list: List[Dict]):
        ScalarInfoFactory.global_scalar_info_dict = {}
        for global_scalar_info in global_scalar_info_dict_list:
            ScalarInfoFactory.global_scalar_info_dict[global_scalar_info['name']] = global_scalar_info

    @staticmethod
    def create_scalar_info(scalar_info: Dict, **kwargs) -> ScalarInfo:
        type = scalar_info["type"]
        if type == "from_curve":
            return ScalarFromCurveInfo(scalar_info, **kwargs)
        elif type == "from_scalars":
            return ScalarFromScalarInfo(scalar_info, global_scalar_info_dict=ScalarInfoFactory.global_scalar_info_dict, **kwargs)
        else:
            raise NotImplementedError()


class TargetInfo:
    """
        存放优化目标信息
    """

    def __init__(self, target_info: Dict):
        self.id = str(target_info['target_id'])
        scalar_info = target_info['scalar']
        self.scalar_info: ScalarInfo = ScalarInfoFactory.create_scalar_info(scalar_info)
        operator = target_info['operator']
        self.optim_type_str = operator
        if operator == "Minimize":
            self.optim_type = TargetComputeConst.MINIMIZE
        elif operator == "Maximize":
            self.optim_type = TargetComputeConst.MAXIMIZE
        else:
            self.optim_type = None
            raise NotImplementedError()
        self.expected = target_info['goal']
        self.weight = target_info['weight']
        self.using_robust_optimization = target_info.get('using_robust_optimization', False)

    def __str__(self):
        return f"{self.scalar_info.name:^10}{self.optim_type_str:^10}{self.expected:^10}{self.weight:^10}{self.using_robust_optimization:^10}"

# def construct_targetlist(args):
#     '''
#     :param args:
#     :return:
#     '''
#     targetlist = []
#     for instance in args.target:
#         target = TargetInfo(function_name=instance.function_name, frequency_range=instance.frequency_range,
#                             optimize_type=instance.optimize_type, predict_method=instance.predict_method)
#         targetlist.append(target)
#     return targetlist
