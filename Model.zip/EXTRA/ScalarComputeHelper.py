import numpy as np
import torch
from typing import Union, List, Sequence

from scipy.signal import find_peaks
import logging

from OptimAlgorithm.Algorithm.codebase.target_helper.multi_target_utils import ScalarInfo, ScalarFromCurveInfo, \
    ScalarFromScalarInfo, \
    CurveDataSourceInfo, DataSourceInfoFactory, ScalarInfoFactory, ScalarComputeConst
from OptimAlgorithm.Algorithm.codebase.utils.constraintHelper import Parser, Lexer, NumberNode, VariableNode, \
    BinaryOpNode, CompareOpNode, min_float, FunctionCallNode

logger = logging.getLogger()


def my_bandwidth(curve_db: np.ndarray, freq_index: np.ndarray, target_db: float, peak=False) -> float:
    """
    计算曲线带宽（波谷定义的）
    Args:
        curve_db: 曲线Y值点列
        freq_index: 曲线X值点列
        target_db: 波谷水平。小于波谷水平的最长频段长度即为带宽
        peak: 为真时，由波峰定义带宽

    Returns:
        float 带宽

    """
    if peak:
        # 查找高于目标dB的索引
        target_indices = np.where(curve_db >= target_db)[0]
    else:
        # 查找低于目标dB值的索引
        target_indices = np.where(curve_db <= target_db)[0]

    # 查找跨越点并计算带宽
    bandwidths = []
    ranges = []
    if len(target_indices) >= 2:
        start_idx = target_indices[0]

        for i in range(1, len(target_indices)):
            if target_indices[i] != target_indices[i - 1] + 1:
                end_idx = target_indices[i - 1]
                lower_freq = freq_index[start_idx]
                upper_freq = freq_index[end_idx]
                bandwidth = upper_freq - lower_freq
                bandwidths.append(bandwidth)
                ranges.append((lower_freq, upper_freq))
                start_idx = target_indices[i]

        # 处理最后一个区间
        end_idx = target_indices[-1]
        lower_freq = freq_index[start_idx]
        upper_freq = freq_index[end_idx]
        bandwidth = upper_freq - lower_freq
        bandwidths.append(bandwidth)
        ranges.append((lower_freq, upper_freq))

    # 选择最大带宽或计算偏离距离
    if bandwidths:
        # 返回最大带宽
        max_bandwidth = max(bandwidths)
        max_range = ranges[bandwidths.index(max_bandwidth)]
        return max_bandwidth
    else:
        # 计算偏离目标dB值的最小距离
        min_deviation = np.min(np.abs(curve_db - target_db))
        return -min_deviation


def my_find_resonance(
        curve_db: np.ndarray,
        freq_index: np.ndarray,
        peak: bool = False,
        *,
        height: Union[None, float, Sequence[float]] = None,
        threshold: Union[None, float, Sequence[float]] = None,
        distance: Union[None, int] = None,
        prominence: Union[None, float, Sequence[float]] = 3,  # todo
        width: Union[None, float, Sequence[float]] = None,
        wlen: Union[None, int] = None,
        rel_height: float = 0.5,
        plateau_size: Union[None, int, Sequence[int]] = None,
) -> int:
    """
    功能
    ----
    在一维幅频曲线中检测谐振点（局部峰值或谷值），并返回满足所有筛选条件的谐振点数量。

    工作流程
    1. 校验 curve_db 与 freq_index 长度一致且为一维。
    2. 若 peak 为 False，则对曲线取反，使谷值转换为峰值。
    3. 调用 scipy.signal.find_peaks，并将所有阈值参数原样透传。
    4. 返回最终保留下来的峰（或谷）数量。

    参数
    curve_db : ndarray
        曲线幅值，单位 dB，一维数组。 单样本输入。
    freq_index : ndarray
        曲线对应频率索引，仅用于长度一致性校验。
    peak : bool, 默认 False
        True  表示检测波峰；False 表示检测波谷（内部取反信号）。
    height : float | (float, float) | None, 默认 None
        绝对幅值阈值。标量表示最小值；二元组 (min, max) 表示闭区间；
        None 表示不使用此条件。
    threshold : float | (float, float) | None, 默认 None
        峰值与左右相邻点均值之差的最小阈值；用法同 height。
    distance : int | None, 默认 None
        相邻保留峰之间的最小水平距离（样本点）。
    prominence : float | (float, float) | None, 默认 None
        峰显著度阈值。显著度定义为峰顶到左右两侧较高谷点的垂直距离；
        波谷模式下在取反信号上计算，同样表示“深度”。
    width : float | (float, float) | None, 默认 None
        峰宽阈值，在 rel_height 指定的相对高度处测得（样本点）。
    wlen : int | None, 默认 None
        计算显著度与宽度时搜索左右基线的窗口长度；None 使用全局。
    rel_height : float, 默认 0.5
        宽度测量的相对高度比例；0.5 表示全宽半高 (FWHM)。
    plateau_size : int | (int, int) | None, 默认 None
        平顶峰（连续相等点平台）的最小或 (最小, 最大) 长度阈值。

    返回值
    int
        满足所有筛选条件的谐振点数量。

    异常
    ValueError
        当 curve_db 与 freq_index 形状不一致或非一维时抛出。

    注意
    · NaN 会被 find_peaks 自动忽略；如需补全请在外部处理。
    · 函数不做平滑滤波；如信号噪声大，请先行滤波。
    · 首尾采样点不参与极值判定。
    """
    # ---------- 输入校验 ----------
    if curve_db.shape != freq_index.shape:
        raise ValueError("curve_db 与 freq_index 长度不一致")

    # ---------- 信号准备 ----------
    signal = curve_db if peak else -curve_db

    # ---------- 调用 SciPy ----------
    peaks, _ = find_peaks(
        signal,
        height=height,
        threshold=threshold,
        distance=distance,
        prominence=prominence,
        width=width,
        wlen=wlen,
        rel_height=rel_height,
        plateau_size=plateau_size,
    )

    # ---------- 返回 ----------
    return len(peaks)


class ScalarComputeHelper:

    def __init__(self, scalar_info_list: List[ScalarInfo], data_index_to_frequency):
        """
        初始化一些参数。
        scalar_info_list：列表。每一个元素是一个ScalarInfo对象。描述了要计算的标量信息。
        """

        self.data_index_to_frequency = data_index_to_frequency
        self.scalar_info_list: List[ScalarInfo] = scalar_info_list

    def compute_scalar_value(self, curve: Union[np.ndarray, torch.Tensor, List],
                             data_index_to_frequency=None):
        cache = {}
        # 将curve转为二维numpy数组
        if isinstance(curve, torch.Tensor):
            curve = curve.detach().cpu().numpy()
        else:
            curve = np.array(curve)

        batch = True  # 判断是否批量返回
        if len(curve.shape) == 1:
            curve = curve.reshape(1, -1)
            batch = False
        scalar_values = np.zeros((curve.shape[0], len(self.scalar_info_list)))

        for i, scalar_info in enumerate(self.scalar_info_list):
            value = self._compute_scalar_value(scalar_info, curve, cache, data_index_to_frequency)
            scalar_values[:, i] = value
        if not batch:
            scalar_values = scalar_values.reshape(len(self.scalar_info_list))
        return scalar_values

    def _compute_scalar_value(self, scalar_info: ScalarInfo, curve, cache, data_index_to_frequency=None):
        value = cache.get(scalar_info.name, None)
        if value is not None:
            return value
        if isinstance(scalar_info, ScalarFromCurveInfo):
            value = self.compute_scalar_from_curve_value(scalar_info, curve, data_index_to_frequency)

        elif isinstance(scalar_info, ScalarFromScalarInfo):
            value = self.compute_scalar_from_scalar_value(scalar_info, curve, cache, data_index_to_frequency)
        else:
            raise NotImplementedError('scalar_info type is not supported')

        cache[scalar_info.name] = value
        return value

    def compute_scalar_from_curve_value(self, scalar_info: ScalarFromCurveInfo, curve, data_index_to_frequency=None):
        if data_index_to_frequency is None:
            data_index_to_frequency = self.data_index_to_frequency
        # 获取数据源曲线对应的频率值(x)值
        frequency_i = data_index_to_frequency[scalar_info.datasource_info.id]
        # 获取数据源曲线对应的y值
        freq_value = curve[:, scalar_info.datasource_info.start_point:scalar_info.datasource_info.end_point]
        # 获取该目标关注数据源的频段
        start_freq, end_freq = scalar_info.freq
        # 获取该目标关注数据源的频段在frequency_i和freq_value中的下标index
        index_of_target_freq_values = np.where((frequency_i >= start_freq) & (frequency_i <= end_freq))[0]
        # 获取该目标关注数据源的频段对应的y值
        target_freq_values = freq_value[:, index_of_target_freq_values]

        operate = scalar_info.operate
        if operate == ScalarComputeConst.MINIMUM:
            # 求最小值
            value = np.min(target_freq_values, axis=1)
        elif operate == ScalarComputeConst.MAXIMUM:
            # 求最大值
            value = np.max(target_freq_values, axis=1)
        elif operate == ScalarComputeConst.AVERAGE:
            # 求均值
            value = np.mean(target_freq_values, axis=1)
        elif operate == ScalarComputeConst.VALLEY_BANDWIDTH:
            # 求小于bw_base的带宽
            bw_base = scalar_info.bw_base
            value = [my_bandwidth(target_freq_values_i, frequency_i[index_of_target_freq_values], bw_base, peak=False)
                     for target_freq_values_i in
                     target_freq_values]
            value = np.array(value)
        elif operate == ScalarComputeConst.PEAK_BANDWIDTH:
            # 求大于bw_base的带宽
            bw_base = scalar_info.bw_base
            value = [my_bandwidth(target_freq_values_i, frequency_i[index_of_target_freq_values], bw_base, peak=True)
                     for target_freq_values_i in
                     target_freq_values]
            value = np.array(value)
        elif operate == ScalarComputeConst.NUM_VALLEY:
            value = [my_find_resonance(target_freq_values_i, frequency_i[index_of_target_freq_values], peak=False) for
                     target_freq_values_i in
                     target_freq_values]
            value = np.array(value)
        elif operate == ScalarComputeConst.NUM_PEAK:
            value = [my_find_resonance(target_freq_values_i, frequency_i[index_of_target_freq_values], peak=True) for
                     target_freq_values_i in
                     target_freq_values]
            value = np.array(value)
        elif operate == ScalarComputeConst.All_Values:
            value = np.array(target_freq_values)
        else:
            raise NotImplementedError('operate type is not supported')
        return value

    def compute_scalar_from_scalar_value(self, scalar_info: ScalarFromScalarInfo, curve, cache,
                                         data_index_to_frequency=None):

        def evaluate(parser):
            # if variables:

            parser.reset_position()  # 在解析前重置解析器的位置

            parse_expression = parser.parse()

            return _evaluate_node(parse_expression)

        def _evaluate_node(node):
            if isinstance(node, NumberNode):
                # print("NumberNode:", node.value)
                return node.value
            elif isinstance(node, VariableNode):
                value = cache.get(node.name, None)
                if value is not None:
                    return value
                node_scalar_info = scalar_info.datasource_info_dict[node.name]
                return self._compute_scalar_value(node_scalar_info, curve, cache, data_index_to_frequency)
            elif isinstance(node, BinaryOpNode):
                left_val = _evaluate_node(node.left)
                right_val = _evaluate_node(node.right)
                if node.operator == 'PLUS':
                    # print("BinaryOpNode (PLUS):", left_val, "+", right_val)
                    return left_val + right_val
                elif node.operator == 'MINUS':
                    # print("BinaryOpNode (MINUS):", left_val, "-", right_val)
                    return left_val - right_val
                elif node.operator == 'TIMES':
                    # print("BinaryOpNode (TIMES):", left_val, "*", right_val)
                    return left_val * right_val
                elif node.operator == 'DIVIDE':
                    # print("BinaryOpNode (DIVIDE):", left_val, "/", right_val)
                    return left_val / right_val
                else:
                    raise ValueError('Invalid operator')
            elif isinstance(node, FunctionCallNode):  # --- 新增: 处理函数调用 ---
                arg_val = _evaluate_node(node.argument)
                if node.name.lower() == 'abs':
                    return np.abs(arg_val)  # <-- 使用 np.abs
                if node.name.lower() == 'custom1':
                    curve_origin = np.loadtxt("./case13_target_set/SCC21.txt")
                    max_diff = np.min(np.abs(arg_val - curve_origin[:, 1][418:468]))
                    return max_diff
                if node.name.lower() == 'custom2':
                    curve_origin = np.loadtxt("./case13_target_set/SDD21.txt")
                    max_diff = np.max(np.abs(arg_val - curve_origin[:, 1][:467]))
                    return max_diff
                else:
                    raise ValueError(f'Unknown function: {node.name}')
            elif isinstance(node, CompareOpNode):
                left_val = _evaluate_node(node.left)
                right_val = _evaluate_node(node.right)
                if node.operator == 'GREATER':
                    # print("CompareOpNode (GREATER):", left_val, ">", right_val)
                    # return left_val > right_val
                    return left_val - min_float >= right_val  # , max(0,right_val-left_val+min_float)     # min_float为sys.float_info.min
                elif node.operator == 'LESS':
                    # print("CompareOpNode (LESS):", left_val, "<", right_val)
                    # return left_val < right_val
                    ll = left_val + min_float
                    return left_val + min_float <= right_val  # , max(0,left_val-right_val+min_float) # min_float为sys.float_info.min
                elif node.operator == 'GEQ':
                    # print("CompareOpNode (GEQ):", left_val, ">=", right_val)
                    return left_val >= right_val  # , max(0,right_val-left_val)
                elif node.operator == 'LEQ':
                    # print("CompareOpNode (LEQ):", left_val, "<=", right_val)
                    return left_val <= right_val  # , max(0,left_val-right_val)
                elif node.operator == 'EQUAL':
                    # print("CompareOpNode (EQUAL):", left_val, "==", right_val)
                    return left_val == right_val  # , abs(left_val-right_val)
                else:
                    raise ValueError('Invalid operator')
            else:
                raise ValueError('Invalid node type')

        return evaluate(scalar_info.parser)


def unit_test():
    curve_data_source_info_dict_list = [
        {'type': 'curve', 'data_dimension': 1001, 'end_point': 1001, 'id': 1,
         'name': '1D Results\\\\S-Parameters\\\\S2(1),1(1)', 'start_point': 0},
        {'type': 'curve', 'data_dimension': 500, 'end_point': 1501, 'id': 2,
         'name': '1D Results\\\\S-Parameters\\\\S2(1),1(2)',
         'start_point': 1001}]
    curve_data_source_info_list = []
    for curve_data_source_info_dict in curve_data_source_info_dict_list:
        curve_data_source_info_list.append(DataSourceInfoFactory.create_data_source_info(curve_data_source_info_dict))

    data_index_to_frequency = {
        curve_data_source_info.id: np.linspace(0, 40, curve_data_source_info.data_dim) for curve_data_source_info in
        curve_data_source_info_list
    }

    scalar_info_dict_list = [
        {'scalar_id': 1, 'name': 'A', 'type': 'from_curve', 'operator': 'Min', 'frequency_range': [10, 20],
         'bw_base': None,
         'source_info': {'id': 1, 'name': '1D Results\\\\S-Parameters\\\\S2(1),1(1)', 'data_dimension': 1001,
                         'start_point': 0,
                         'end_point': 1001}},
        {'scalar_id': 2, 'name': 'B', 'type': 'from_curve', 'operator': 'bandwidth', 'frequency_range': [20, 30],
         'bw_base': -10.0,
         'source_info': {'id': 2, 'name': '1D Results\\\\S-Parameters\\\\S2(1),1(2)', 'data_dimension': 500,
                         'start_point': 1001, 'end_point': 1501}},
        {'scalar_id': 3, 'name': 'C', 'type': 'from_scalars', 'expression': '2*B-A'},
        {'scalar_id': 4, 'name': 'D', 'type': 'from_scalars', 'expression': '3+A*B-C/200'},
        ]

    ScalarInfoFactory.update_global_scalar_info_dict(scalar_info_dict_list)
    scalar_info_list = []
    for scalar_info_dict in scalar_info_dict_list:
        scalar_info_list.append(ScalarInfoFactory.create_scalar_info(scalar_info_dict))

    scalar_compute_helper = ScalarComputeHelper(scalar_info_list, data_index_to_frequency)
    total_dim = 0
    for curve_data_source_info in curve_data_source_info_list:
        total_dim += curve_data_source_info.data_dim
    curve = [
        np.arange(total_dim),
        np.arange(total_dim)[::-1]
    ]
    # curve = np.random.random((5,curve_data_source_info1.data_dim + curve_data_source_info2.data_dim))

    value = scalar_compute_helper.compute_scalar_value(curve)
    print(value)


if __name__ == '__main__':
    unit_test()
